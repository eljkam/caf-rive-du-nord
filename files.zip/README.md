# Rive du Nord Café — démo vitrine

Mini-site statique responsive pour un café fictif à Martil. Il utilise HTML, CSS et JavaScript vanilla, sans backend, framework, compilation ni dépendance obligatoire.

## Fichiers

- `index.html` — structure, contenu et référencement de base.
- `style.css` — styles responsives et animations.
- `script.js` — menu mobile, liens configurables, navbar et apparitions au scroll.

## Ouvrir localement

Ouvrez `index.html` dans un navigateur. Une connexion Internet est nécessaire pour charger les photos Unsplash et les polices Google Fonts. Le site reste navigable sans JavaScript, mais les interactions et liens configurés nécessitent JavaScript.

## Personnalisation avant une mise en ligne réelle

1. **Coordonnées WhatsApp** — dans `script.js`, renseignez `whatsappNumber` avec le numéro au format international sans `+`, espaces ni tirets. Exemple de format : `212600000000`. Tant que la valeur est vide, le lien ouvre WhatsApp avec le message prérempli et laisse le visiteur choisir le destinataire.
2. **Google Maps** — remplacez `mapsQuery` dans `script.js` par l’adresse réelle ou les coordonnées GPS du commerce.
3. **Instagram** — remplacez `instagramUrl` par l’URL du compte réel.
4. **Adresse, téléphone et horaires** — mettez à jour les éléments correspondants dans `index.html`. Les coordonnées et horaires présents dans cette démo sont fictifs ou indiqués comme à renseigner.
5. **Menu et prix** — modifiez directement les noms et montants dans la section Menu de `index.html`. Les prix affichés sont des exemples de démonstration.
6. **Photos** — remplacez les URLs Unsplash des attributs `src` dans `index.html`. Les images utilisent `loading="lazy"` sauf l’image principale, prioritaire au chargement.
7. **SEO** — adaptez le titre, la description et les métadonnées Open Graph dans l’en-tête de `index.html`.

Les liens de navigation et les boutons de contact sont fonctionnels. Aucun numéro de téléphone ou compte de commerce réel n’est inventé.

## Déploiement sur GitHub Pages

1. Ajoutez les quatre fichiers à la racine d’un dépôt GitHub.
2. Ouvrez **Settings → Pages**.
3. Choisissez la branche à publier et le dossier `/ (root)`.
4. Enregistrez. GitHub Pages servira automatiquement `index.html`.

Aucune étape de build n’est requise.

## Accessibilité

Le site inclut un lien d’évitement vers le contenu, des libellés accessibles, une navigation clavier, un bouton de menu mobile avec état ARIA, des descriptions d’images et la prise en compte de la préférence `prefers-reduced-motion`.